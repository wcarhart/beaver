# __init__.py

# Version of the beaver package
__version__ = "1.0.0"